# prompts-for-podcast-generate-by-ia
Este repositório contém um guia passo a passo para criar roteiros de podcast sobre como a inteligência artificial auxilia na medicina, especialmente no desenvolvimento de soluções contra bactérias resistentes. Inclui exemplos de prompts, estrutura de roteiro e uma imagem de capa para o projeto.
